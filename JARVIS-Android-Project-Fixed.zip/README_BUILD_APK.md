# JARVIS Android App

This is the Android Studio project extracted from the supplied ZIP. A launcher icon has been added because the manifest references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.

## Build an APK with GitHub Actions (no Android SDK needed on your PC)

1. Create a new GitHub repository.
2. Upload the contents of this folder (the files inside `JARVIS-Android-Kotlin-Projectnew`), not the enclosing ZIP.
3. Open the repository's **Actions** tab.
4. Select **Build JARVIS Android APK** and click **Run workflow** (or push to `main` / `master`).
5. When the workflow completes, open its run and download the **JARVIS-debug-apk** artifact.
6. Extract the artifact ZIP; it contains `app-debug.apk`. Transfer it to your Android phone and install it. You may need to allow installation from that file manager/browser.

## API keys

The app stores API keys in its Settings screen. To use online AI and weather features, enter the appropriate keys:
- Gemini API key for Gemini chat / AI responses.
- Picovoice AccessKey for the "Hey JARVIS" wake-word feature.
- OpenWeather API key for weather.

Without the relevant keys, those online/provider-dependent features may not work. Do not publish your API keys in the GitHub repository.

## Project build settings

- Android Gradle Plugin: 8.2.2
- Gradle: 8.5 (provided by the included GitHub Actions workflow)
- JDK: 17
- compileSdk: 34
- minSdk: 24 (Android 7.0+)

The debug APK produced by the workflow is for testing. A signed release APK requires a signing key and signing configuration.
