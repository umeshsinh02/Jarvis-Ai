# JARVIS Android App — APK बनाने का तरीका

यह आपके दिए हुए Kotlin Android प्रोजेक्ट की फाइलें हैं। मूल प्रोजेक्ट के AndroidManifest.xml में launcher icon के references थे, लेकिन icon files ZIP में मौजूद नहीं थीं। इस पैकेज में आवश्यक launcher icons जोड़ दिए गए हैं।

## GitHub से APK बनाएं

1. GitHub पर नया repository बनाएं।
2. इस ZIP के अंदर की सभी फाइलें repository में upload करें।
3. Repository के **Actions** टैब में जाएं।
4. **Build JARVIS Android APK** workflow चुनें और **Run workflow** दबाएं। `main` या `master` branch पर push करने से भी build शुरू होगा।
5. Workflow पूरा होने पर run खोलें और **JARVIS-debug-apk** artifact डाउनलोड करें।
6. Artifact ZIP extract करें। उसमें `app-debug.apk` मिलेगा। इसे Android फोन में भेजकर install करें। जरूरत पड़ने पर file manager/browser को unknown apps install करने की अनुमति दें।

## जरूरी API keys

ऐप की Settings स्क्रीन में ये keys डालें:
- Gemini API key — AI chat के लिए
- Picovoice AccessKey — “Hey JARVIS” wake-word के लिए
- OpenWeather API key — weather फीचर के लिए

इन keys को GitHub repository में सार्वजनिक रूप से न डालें। संबंधित key के बिना उसका online/provider-dependent feature काम नहीं करेगा।

## Build जानकारी

- Android Gradle Plugin 8.2.2
- Gradle 8.5
- JDK 17
- compileSdk 34
- minSdk 24 (Android 7.0+)

GitHub Actions debug/testing APK बनाता है। Signed release APK के लिए अलग signing key/configuration चाहिए।
